吾苍耳冯福密码编辑器 Android 工程
================================

这是 Android Studio 工程源码，不是已经编译好的 APK。
当前制作环境没有 Android SDK/Gradle 构建环境，因此不能在这里直接产出可安装 APK。

如何编译 APK（Windows / macOS / Linux）
1. 安装 Android Studio（官方渠道下载）。
2. 解压本 ZIP。
3. Android Studio 选择 Open，打开解压后的 WucangerfengfuAndroid 文件夹。
4. 等待 Gradle 同步完成；如提示安装 Android SDK 35，请按提示安装。
5. 菜单选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
6. 编译成功后，点击通知中的 locate，或在项目目录查找：
   app/build/outputs/apk/debug/app-debug.apk
7. 将 app-debug.apk 传到安卓手机，允许该来源安装应用后安装。

工程信息
- 应用名：吾苍耳冯福密码编辑器
- 包名：com.wucangerfengfu.editor
- 最低 Android：Android 6.0（API 23）
- 网页资源内置在 APK 中，日常使用不需要网络权限。
- 输入和转换在本机 WebView 中运行。

提示
- 第一次打开应用仍会显示免责声明；点击同意后进入。
- 本工具是可逆编码/混淆，不是 AES 等密码学加密。不要用来保护真正的账号密码或敏感资料。
- 如需发布到应用商店，请自行配置正式签名、隐私政策和商店合规资料。


更简单的云端编译方式（不必在自己的电脑安装 Android Studio）
1. 登录 GitHub，创建一个新的空仓库（Repository），例如 Wucangerfengfu。
2. 解压本工程 ZIP，把里面所有文件和文件夹上传到仓库根目录（包括隐藏的 .github 文件夹）。
3. 上传到 main 分支后，打开仓库的 Actions 页面。
4. 选择 “Build Android APK”，点击 “Run workflow”（如果 push 自动触发则等待完成）。
5. 工作流成功后，打开本次运行记录页面，在 Artifacts 区域下载
   wucangerfengfu-debug-apk。
6. 解压下载的 ZIP，得到 app-debug.apk，传到安卓手机安装。

注意：GitHub 账号及仓库按 GitHub 当前规则使用；公开仓库会公开源代码。
若要保持源码私密，请创建 Private 仓库。首次运行需要等待 GitHub 云端构建完成。
